package com.tanzy.sherlockdemo.entity

import android.content.Intent

/**
 * Created by tanzy on 2020/6/12.
 */
data class DemoEntity(
    var name: String,
    var intent: Intent
)