package com.tanzy.sherlockdemo.dialoganim

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.tanzy.sherlockdemo.R

class DialogAnimActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dialog_anim)
    }
}
